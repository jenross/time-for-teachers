module.exports = {
  User: require("./User"),
  UserData: require("./UserData")
};
